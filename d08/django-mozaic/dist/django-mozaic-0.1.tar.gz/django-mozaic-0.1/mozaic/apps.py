from django.apps import AppConfig


class MozaicConfig(AppConfig):
    name = 'mozaic'
